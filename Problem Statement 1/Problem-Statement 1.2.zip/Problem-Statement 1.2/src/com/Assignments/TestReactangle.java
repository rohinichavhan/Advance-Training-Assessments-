package com.Assignments;

import java.util.Scanner;

public class TestReactangle {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
	System.out.println("Enter Length and breath:");
		
	Rectangle rect1=new Rectangle( sc.nextDouble(),sc.nextDouble());
	rect1.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	
	System.out.println("============================================");
	Rectangle rect2=new Rectangle( sc.nextDouble(),sc.nextDouble());
	rect2.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	Rectangle rect3=new Rectangle( sc.nextDouble(),sc.nextDouble());
	rect3.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	Rectangle rect4=new Rectangle( sc.nextDouble(),sc.nextDouble());
	rect4.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	Rectangle rect5=new Rectangle( sc.nextDouble(),sc.nextDouble());
	rect5.area();
	    
    
	    }

}
